package com.example.wallpaperapplication.models

import com.example.wallpaperapplication.models.helperModels.UnsplashImageModelItem

class UnsplashImageModel : ArrayList<UnsplashImageModelItem>()