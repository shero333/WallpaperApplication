package com.example.wallpaperapplication.models.helperModels

data class Links(
    val download: String,
    val download_location: String,
    val html: String,
    val self: String
)