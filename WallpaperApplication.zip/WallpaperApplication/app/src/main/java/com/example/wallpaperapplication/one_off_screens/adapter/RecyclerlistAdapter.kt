package com.example.wallpaperapplication.one_off_screens.adapter

import android.annotation.SuppressLint
import android.app.Application
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.AppCompatImageView
import androidx.appcompat.widget.AppCompatTextView
import androidx.recyclerview.widget.RecyclerView
import com.example.wallpaperapplication.R
import com.example.wallpaperapplication.models.InterestUser

class RecyclerlistAdapter(private var itemSelected:ItemSelected) : RecyclerView.Adapter<RecyclerlistAdapter.ListAdapterViewHolder>() {

    var interestList: ArrayList<InterestUser>? = null
    private var selected_interest_position = 0


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListAdapterViewHolder {

        val view = LayoutInflater.from(parent.context).inflate(R.layout.interest_items_view,parent,false)
        return ListAdapterViewHolder(view)
    }

    override fun onBindViewHolder(holder: ListAdapterViewHolder, position: Int) {

        val itemPosition = position

        holder.itemName.text = interestList!![position].getName()

        changeItemBackground(holder,interestList!![position].getSelected() && selected_interest_position == position)

        holder.itemView.setOnClickListener {

            if (selected_interest_position != itemPosition) {
                selected_interest_position = itemPosition
                itemSelected.selectedItemName(interestList!![position], itemPosition)

            }
        }
    }

    override fun getItemCount(): Int {
        if (interestList != null)
            return interestList!!.size
        else
            return 0
    }

    @SuppressLint("NotifyDataSetChanged")
    fun changeSelectionStatus(position: Int) {
        for (interest in interestList!!) {
            interest.setSelected(selected_interest_position == position)
        }
        notifyDataSetChanged()
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    fun changeItemBackground(
        holder: ListAdapterViewHolder,
        isSelected: Boolean
    ) {
        if (isSelected) {
            holder.itemName.isSelected = true
            holder.selectionImage.setImageResource(R.drawable.selected)

        } else {
            holder.itemName.isSelected =false
            holder.selectionImage.setImageResource(0)
        }
    }

    class ListAdapterViewHolder(itemView:View) : RecyclerView.ViewHolder(itemView){

        val itemName: AppCompatTextView = itemView.findViewById(R.id.listItem)
        val selectionImage: AppCompatImageView = itemView.findViewById(R.id.selection_image)

    }

    interface ItemSelected{
        fun selectedItemName(interest:InterestUser,position:Int)
    }
}