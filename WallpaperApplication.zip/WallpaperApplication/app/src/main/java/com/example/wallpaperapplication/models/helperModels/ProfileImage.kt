package com.example.wallpaperapplication.models.helperModels

data class ProfileImage(
    val large: String,
    val medium: String,
    val small: String
)