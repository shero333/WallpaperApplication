package com.example.wallpaperapplication

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.WindowManager
import android.widget.TextView
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.splashscreen.SplashScreen
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.example.wallpaperapplication.databinding.ActivitySplashBinding
import com.example.wallpaperapplication.main_screen.MainScreenActivity
import com.google.android.material.snackbar.Snackbar
import com.google.android.play.core.appupdate.AppUpdateManager
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.install.InstallStateUpdatedListener
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.InstallStatus
import com.google.android.play.core.install.model.UpdateAvailability

@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {

    private lateinit var appUpdateManager: AppUpdateManager
    private lateinit var binding: ActivitySplashBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivitySplashBinding.inflate(layoutInflater)

        val splashScreen: SplashScreen = installSplashScreen()

        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        setContentView(binding.root)

        splashScreen.setKeepOnScreenCondition { true }

        //app update
        appUpdateManager = AppUpdateManagerFactory.create(this)
        appUpdateManager.appUpdateInfo.addOnSuccessListener {

            if (it.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE &&
                it.isUpdateTypeAllowed(AppUpdateType.FLEXIBLE)){

                appUpdateManager.startUpdateFlowForResult(it,AppUpdateType.FLEXIBLE,this@SplashActivity,100)
            }else{
                startActivity(Intent(this@SplashActivity, MainScreenActivity::class.java))
                finish()
            }
        }
            .addOnFailureListener {

                startActivity(Intent(this@SplashActivity, MainScreenActivity::class.java))
                finish()

            }

        appUpdateManager.registerListener(installStateUpdatedListener)

    }

    private val installStateUpdatedListener : InstallStateUpdatedListener = InstallStateUpdatedListener {

        if (it.installStatus() == InstallStatus.DOWNLOADED){

            val snackbar = Snackbar.make(
                binding.root, "App updated successfully",
                Snackbar.LENGTH_INDEFINITE
            ).setAction("Install") {

                appUpdateManager.completeUpdate()

            }
            snackbar.setActionTextColor(Color.GREEN)
            val snackbarView = snackbar.view
            snackbarView.setBackgroundColor(resources.getColor(R.color.icon_splash_background))
            val textView = snackbarView.findViewById(com.google.android.material.R.id.snackbar_text) as TextView
            textView.setTextColor(Color.WHITE)
            textView.textSize = 28f
            snackbar.show()

        }
    }

    @Deprecated("Deprecated in Java", ReplaceWith("super.onActivityResult(requestCode, resultCode, data)",
        "androidx.appcompat.app.AppCompatActivity"))
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

    }

    override fun onStop() {
        appUpdateManager.unregisterListener(installStateUpdatedListener)
        super.onStop()
    }
}