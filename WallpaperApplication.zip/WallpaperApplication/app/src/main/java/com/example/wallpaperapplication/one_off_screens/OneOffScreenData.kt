package com.example.wallpaperapplication.one_off_screens

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.example.wallpaperapplication.R
import com.example.wallpaperapplication.databinding.ActivityOneOffScreenDataBinding
import com.example.wallpaperapplication.models.InterestUser
import com.example.wallpaperapplication.one_off_screens.adapter.RecyclerlistAdapter

class OneOffScreenData : AppCompatActivity(), RecyclerlistAdapter.ItemSelected {

    private lateinit var binding:ActivityOneOffScreenDataBinding
    private lateinit var interestAdapter: RecyclerlistAdapter


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityOneOffScreenDataBinding.inflate(layoutInflater)

        setContentView(binding.root)

        interestAdapter = RecyclerlistAdapter(this)

        val interestNames = ArrayList<InterestUser>()

        interestNames.add(InterestUser(resources.getStringArray(R.array.interestNames)[0]))
        interestNames.add(InterestUser(resources.getStringArray(R.array.interestNames)[1]))
        interestNames.add(InterestUser(resources.getStringArray(R.array.interestNames)[2]))
        interestNames.add(InterestUser(resources.getStringArray(R.array.interestNames)[3]))
        interestNames.add(InterestUser(resources.getStringArray(R.array.interestNames)[4]))
        interestNames.add(InterestUser(resources.getStringArray(R.array.interestNames)[5]))
        interestNames.add(InterestUser(resources.getStringArray(R.array.interestNames)[6]))
        interestNames.add(InterestUser(resources.getStringArray(R.array.interestNames)[7]))

        interestAdapter.interestList = interestNames

        binding.interestList.setHasFixedSize(true)
        binding.interestList.layoutManager = LinearLayoutManager(this@OneOffScreenData,LinearLayoutManager.VERTICAL,false)
        binding.interestList.adapter = interestAdapter
    }

    override fun selectedItemName(interest: InterestUser, position: Int) {

        interestAdapter.changeSelectionStatus(position)

    }
}