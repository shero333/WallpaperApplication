package com.example.wallpaperapplication.repository.retroinjection

import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.liveData
import com.example.wallpaperapplication.repository.Api
import javax.inject.Inject

class UnsplashRepository @Inject constructor(private val api: Api) {

//    fun CallWallpaperApi() = Pager(
//        config = PagingConfig(pageSize = 30, maxSize = 100),
//        pagingSourceFactory = { LoadPage(api) }
//    ).liveData
}